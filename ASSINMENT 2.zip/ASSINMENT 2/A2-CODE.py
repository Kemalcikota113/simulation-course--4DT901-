import math
import sys
import random

Q_LIMIT = 6
IDLE_STATUS = 0
BUSY_STATUS = 1
SERVERS_COUNT = 4

next_event_type = 0
num_of_cust_delayed = 0
num_delays_required = 0
total_arrivals = 0

area_num_in_q = 0.0
area_server_status = 0.0

mean_interarrival = 34
mean_service = 10.499

clock = 0.0
time_last_event = 0.0
total_of_delays = 0.0
total_time_in_system = 0.0
num_custs_delayed = 0
num_of_customers_not_served = 0


buffer = []
servers = []

next_arrival = 0.0

ARRIVAL_EVENT = 0
DEPARTURE_EVENT = 1
EXIT_SIMULATION_EVENT = 3

MAX_WORKING_HOURS_PER_DAY = 8
DAYS_RUN_SIM_FOR = 10

server_status = [IDLE_STATUS] * SERVERS_COUNT

#def get_mean_and_variance(numbers):
 # mean = sum(numbers) / len(numbers)
  #variance = sum((x - mean) ** 2 for x in numbers) / (len(numbers) - 1)
  #return mean, variance

def get_mean_and_variance(numbers, sample=True):
    if len(numbers) == 0:
        return 0, 0
    mean = sum(numbers) / len(numbers)
    variance = sum((x - mean) ** 2 for x in numbers) / (len(numbers) - 1 if sample else len(numbers))
    return mean, variance

def get_next_moment(rate):
  return -math.log(random.random())/rate

def initialize():
  global clock, SERVERS_COUNT, server_status, servers, next_arrival, next_event_type, buffer, time_last_event, area_server_status, num_of_customers_not_served, num_of_cust_delayed, total_arrivals, total_time_in_system, area_num_in_q
  clock = 0.0
  area_server_status = 0.0
  servers = []

  next_arrival = clock + get_next_moment(mean_interarrival)
  next_event_type = ARRIVAL_EVENT
  num_of_customers_not_served = 0
  num_of_cust_delayed = 0
  total_arrivals = 0
  total_time_in_system =0.0
  area_num_in_q = 0.0

  buffer = []
  time_last_event = 0.0

def timing():
  global next_arrival, servers, clock, next_event_type

  earliest_event = min([next_arrival] + servers)

  if next_arrival == earliest_event:
    next_event_type = ARRIVAL_EVENT
  else:
    next_event_type = DEPARTURE_EVENT

  # Advance time
  clock = earliest_event

def arrival():
  global num_of_cust_delayed, next_arrival, buffer, servers, server_status, mean_service, clock, num_of_customers_not_served, total_arrivals, total_time_in_system, total_of_delays
  # schedule next arrival
  total_arrivals+=1
  next_arrival = clock + get_next_moment(mean_interarrival)
  if len(servers) == SERVERS_COUNT:
    #print("Server too busy to pick request")
    if len(buffer) <= Q_LIMIT:
      buffer.append(clock)
      buffer.sort()
    else:
      #print("Reuqest cannot be queued as it buffer limit has MAXED")
      num_of_customers_not_served+=1
  else:
    num_of_cust_delayed += 1
    total_of_delays += 0
    service_time = get_next_moment(mean_service)

    total_time_in_system+=service_time
    servers.append(clock + service_time)
    servers.sort()

def depart():
  global num_custs_delayed, total_of_delays, buffer, servers, server_status, mean_service, clock, num_of_cust_delayed, total_time_in_system

  # remove first item from servers
  servers.pop(0)

  # when there is customers in buffer
  if len(buffer) > 0:
    delay = clock - buffer.pop(0)
    total_of_delays += delay
    num_of_cust_delayed += 1

    service_time = get_next_moment(mean_service)
    servers.append(clock + service_time)
    servers.sort()
    total_time_in_system += (delay + service_time)
    #servers.sort()


def update_time_avg_stats():
  global time_last_event, clock, area_num_in_q, area_server_status
  time_since_last_event = clock - time_last_event
  time_last_event = clock

  area_num_in_q += len(buffer) * time_since_last_event
  area_server_status += (len(servers) / SERVERS_COUNT) * time_since_last_event

runs_data =[]
days_count = 1
while days_count <= DAYS_RUN_SIM_FOR:
  initialize()

  evets_count =1

  while evets_count <= 1000:
    timing()
    update_time_avg_stats()
    event_name = "Exit"

    if next_event_type == ARRIVAL_EVENT:
      event_name = "Arrival"
      arrival()
      evets_count+=1
    elif next_event_type == DEPARTURE_EVENT:
      event_name = "Departure"
      depart()
    # print(f"⏲️[{clock}] {event_name}, Q length: {len(buffer)}")

  runs_data.append({
      'customers served': num_of_cust_delayed,
      'total arrivals': total_arrivals,
      'total queue': area_num_in_q,
      'area_server_status': area_server_status,
      'dropped customers': num_of_customers_not_served,
      'clock (min)': clock,
      'total spent in system': total_time_in_system,
      'response time (min)': total_time_in_system / num_of_cust_delayed,
      'server utilization': area_server_status / clock,
      'drop rate (min^-1)': num_of_customers_not_served / clock,
      })
  days_count+=1

print("")
print("")

# Create headers
#headers = runs_data[0].keys()
headers = ['customers served', 'total queue', 'dropped customers', 'clock (min)', 'response time (min)', 'server utilization', 'drop rate (min^-1)']

# Create header row with formatted spacing
header_row = " | ".join(f"{header:<20}" for header in headers)
print(header_row)
print("-" * len(header_row))  # Print a separator line

# Print each row of data with formatted spacing
for entry in runs_data:
    row = " | ".join(f"{entry[key]:<20}" for key in headers)
    print(row)


avg_response_time, variance_response_time = get_mean_and_variance([run['response time (min)'] for run in runs_data])
avg_server_utilization, variance_server_utilization = get_mean_and_variance([run['server utilization'] for run in runs_data])
avg_drop_rate, variance_drop_rate = get_mean_and_variance([run['drop rate (min^-1)'] for run in runs_data])

print("")
print("")
print(f'Average response time: {avg_response_time}')
print(f'Average server utilization: {avg_server_utilization}')
print(f'Average drop rate: {avg_drop_rate}')

print("")
print("")
print(f'Variance response time: {variance_response_time}')
print(f'Variance server utilization: {variance_server_utilization}')
print(f'Variance drop rate: {variance_drop_rate}')

conf_interval_response_time = 2.26 * math.sqrt(variance_response_time / len(runs_data))
conf_server_utilization = 2.26 * math.sqrt(variance_server_utilization / len(runs_data))
conf_drop_rate = 2.26 * math.sqrt(variance_drop_rate / len(runs_data))

print("")
print("")
print(f'Confidence interval response time: {conf_interval_response_time}')
print(f'Confidence interval server utilization: {conf_server_utilization}')
print(f'Confidence interval drop rate: {conf_drop_rate}')


repetions_for_response_time = (1.96*math.sqrt(variance_response_time)/0.1)**2
repetions_for_server_utilization = (1.96*math.sqrt(variance_server_utilization)/0.1)**2
repetions_for_drop_rate = (1.96*math.sqrt(variance_drop_rate)/0.1)**2

print("")
print("")
print("Considering 95% confidence with error margin of 10% we get")
print(f'Repetitions for response time: {repetions_for_response_time}')
print(f'Repetitions for server utilization: {repetions_for_server_utilization}')
print(f'Repetitions for drop rate: {repetions_for_drop_rate}')
